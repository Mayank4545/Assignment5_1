
public class Triangle extends Figure{

	public Triangle(double dim1,double dim2,double dim3) {
		super(dim1,dim2,dim3);		
	}
	
	double sideA = dim1;
	double sideB = dim2;
	double sideC = dim3;
	double S;
	
	
	@Override
	void findArea() {
		S = (sideA + sideB + sideC)/2;
		area = Math.sqrt(S*(S-sideA)*(S-sideB)*(S-sideC));
		System.out.println("Area of triangle = " + area);
	}

	@Override
	void findPerimeter() {
		perimeter = sideA + sideB + sideC;
		System.out.println("Peremeter of triangle = " + perimeter);
	}
}