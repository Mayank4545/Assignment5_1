
public abstract class Figure {
	
	double dim1;
	double dim2;
	double dim3;
	double area;
	double perimeter;
	
	/* Constructor with one parameter for radius of Circle*/	
	public Figure(double dim1) {
		super();
		this.dim1 = dim1;
	}
	
	/* Constructor with two parameters for length and breadth of Rectangle*/	
	public Figure(double dim1,double dim2){
		super();
		this.dim1 = dim1;
		this.dim2 = dim2;
	}
	
	/* Constructor with three parameter for all three sides of Triangle*/	
	public Figure(double dim1,double dim2,double dim3){
		super();
		this.dim1 = dim1;
		this.dim2 = dim2;
		this.dim3 = dim3;
	}
	
//	Abstract methods whose implementations are in child classes
	abstract void findArea();
	abstract void findPerimeter();
	
}
