import java.util.Scanner;

public class Assignment5_1 {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		System.out.println("Enter radius of circle : ");
		double radius = s.nextDouble();
		
		/*Call constructor with one parameter and then call method for calculations*/
		Figure figCircle = new Circle(radius);
		callCircle(figCircle);
		
		System.out.println();
		System.out.println("Enter details of Rectangle :");
		System.out.println("Length = ");
		double length = s.nextDouble();
		System.out.println("Breadth = ");
		double breadth = s.nextDouble();		
		
		/*Call constructor with two parameters and then call method for calculations*/
		Figure figRectangle = new Rectangle(length,breadth);		
		callRectangle(figRectangle);
		
		System.out.println();
		System.out.println("Enter details of Triangle:");
		System.out.println("Side A = ");
		double sideA = s.nextDouble();
		System.out.println("Side B = ");
		double sideB = s.nextDouble();
		System.out.println("Side C = ");
		double sideC = s.nextDouble();
		
		/*Call constructor with three parameter and then call method for calculations*/
		Figure figTriangle = new Triangle(sideA,sideB,sideC);
		callTrianlge(figTriangle);
		
		System.out.println();
		System.out.println("Thank you");  /*End of execution*/
	}
	
	public static void callCircle(Figure figure){ /*Goes to Circle class since object is created for Circle*/
		figure.findArea();
		figure.findPerimeter();
	}
	public static void callRectangle(Figure figRectangle){ /*Goes to Rectangle class since object is created for Rectangle*/
		figRectangle.findArea();
		figRectangle.findPerimeter();
	}
	public static void callTrianlge(Figure figTriangle){ /*Goes to Triangle class since object is created for Triangle*/
		figTriangle.findArea();
		figTriangle.findPerimeter();
	}
	
}
