
public class Circle extends Figure{

	public Circle(double radius) {
		super(radius);
	}

	double radius = dim1;
	
	@Override
	void findArea() {
		
		area = Math.PI * radius * radius;
		System.out.println();
		System.out.println("Area of circle = " + area);
	}

	@Override
	void findPerimeter() {
		
		perimeter = 2 * Math.PI * radius;
		System.out.println("Perimeter of circle = " +perimeter );
	}

}
