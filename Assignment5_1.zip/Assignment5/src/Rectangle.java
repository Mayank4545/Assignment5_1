
public class Rectangle extends Figure{

	public Rectangle(double length, double breadth) {
		super(length,breadth);
	}
	
	double length = dim1;
	double breadth = dim2;
	
	@Override
	void findArea() {
		
		area = length * breadth;
		System.out.println();
		System.out.println("Area of rectangle = " + area);
	}

	@Override
	void findPerimeter() {
			
		perimeter = 2 * (length + breadth);
		System.out.println("peremeter of rectangle = " + perimeter);
	}

}
